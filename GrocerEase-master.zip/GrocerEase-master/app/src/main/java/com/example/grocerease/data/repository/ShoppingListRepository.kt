package com.example.grocerease.data.repository

import androidx.lifecycle.LiveData
import com.example.grocerease.data.dao.ShoppingListDao
import com.example.grocerease.data.database.entities.ShoppingListItem

class ShoppingListRepository(private val shoppingListDao: ShoppingListDao) {

    val allItems: LiveData<List<ShoppingListItem>> = shoppingListDao.getAllItems()

    suspend fun addItem(item: ShoppingListItem) {
        shoppingListDao.addItem(item)
    }

    suspend fun removeItem(itemId: Int) {
        shoppingListDao.removeItem(itemId)
    }

    suspend fun updateQuantity(itemId: Int, quantity: Int) {
        shoppingListDao.updateQuantity(itemId, quantity)
    }

    suspend fun clearCompleted() {
        shoppingListDao.clearCompleted()
    }
} 