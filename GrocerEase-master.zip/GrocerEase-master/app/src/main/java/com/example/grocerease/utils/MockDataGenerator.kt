package com.example.grocerease.utils

import com.example.grocerease.data.database.entities.Category
import com.example.grocerease.data.database.entities.Product

object MockDataGenerator {

    fun getCategories(): List<Category> {
        return listOf(
            Category(1, "Fruits & Vegetables", "Φρούτα & Λαχανικά", "category_fruits_vegetables"),
            Category(2, "Dairy & Eggs", "Γαλακτοκομικά & Αυγά", "category_dairy_eggs"),
            Category(3, "Meat & Seafood", "Κρέας & Θαλασσινά", "category_meat_seafood"),
            Category(4, "Pantry Essentials", "Είδη Παντοπωλείου", "category_pantry_essentials"),
            Category(5, "Beverages", "Ποτά", "category_beverages"),
            Category(6, "Household Items", "Είδη Οικιακής Χρήσης", "category_household_items")
        )
    }

    fun getProducts(): List<Product> {
        return listOf(
            // Fruits & Vegetables
            Product(1, "Bananas", "Μπανάνες", "Fruits & Vegetables", 1.29, "kilo", "Fresh, ripe bananas.", "Φρέσκες, ώριμες μπανάνες.", "Rich in potassium.", "product_bananas_fruits_vegetables", availabilityAmount = 50),
            Product(2, "Carrots", "Καρότα", "Fruits & Vegetables", 0.99, "kilo", "Organic carrots.", "Βιολογικά καρότα.", "High in Vitamin A.", "product_carrot_fruits_vegetables", availabilityAmount = 100),
            Product(3, "Green Apples", "Πράσινα Μήλα", "Fruits & Vegetables", 2.49, "kilo", "Crisp and tart green apples.", "Τραγανά και ξινά πράσινα μήλα.", "Great for baking.", "product_greenapple_fruits_vegetables", availabilityAmount = 80),
            Product(4, "Lemons", "Λεμόνια", "Fruits & Vegetables", 1.99, "kilo", "Juicy lemons.", "Ζουμερά λεμόνια.", "Perfect for drinks and cooking.", "product_lemon_fruits_vegetables", availabilityAmount = 60),
            Product(5, "Onions", "Κρεμμύδια", "Fruits & Vegetables", 0.89, "kilo", "Fresh onions.", "Φρέσκα κρεμμύδια.", "A kitchen staple.", "product_onion_fruits_vegetables", availabilityAmount = 120),
            Product(6, "Potatoes", "Πατάτες", "Fruits & Vegetables", 1.19, "kilo", "Versatile potatoes.", "Ευέλικτες πατάτες.", "Ideal for roasting or mashing.", "product_potato_fruits_vegetables", availabilityAmount = 200),
            Product(7, "Red Apples", "Κόκκινα Μήλα", "Fruits & Vegetables", 2.29, "kilo", "Sweet and crunchy red apples.", "Γλυκά και τραγανά κόκκινα μήλα.", "A healthy snack.", "product_redapple_fruits_vegetables", availabilityAmount = 90),
            Product(8, "Tomatoes", "Ντομάτες", "Fruits & Vegetables", 3.49, "kilo", "Ripe vine tomatoes.", "Ώριμες ντομάτες.", "Perfect for salads.", "product_tomato_fruits_vegetables", availabilityAmount = 70),

            // Dairy & Eggs
            Product(9, "Butter", "Βούτυρο", "Dairy & Eggs", 3.99, "unit", "Creamy unsalted butter.", "Κρεμώδες ανάλατο βούτυρο.", "250g pack.", "product_butter_dairy_eggs", availabilityAmount = 40),
            Product(10, "Eggs", "Αυγά", "Dairy & Eggs", 2.99, "unit", "Box of 12 free-range eggs.", "Κουτί με 12 αυγά ελευθέρας βοσκής.", "Rich in protein.", "product_eggs_dairy_eggs", availabilityAmount = 50),
            Product(11, "Milk", "Γάλα", "Dairy & Eggs", 1.49, "litre", "Fresh whole milk.", "Φρέσκο πλήρες γάλα.", "1 litre carton.", "product_milk_dairy_eggs", availabilityAmount = 100),
            Product(12, "Yellow Cheese", "Κίτρινο Τυρί", "Dairy & Eggs", 8.99, "kilo", "Mild yellow cheese.", "Ήπιο κίτρινο τυρί.", "Great for sandwiches.", "product_yellowcheese_dairy_eggs", availabilityAmount = 30),
            Product(13, "Yogurt", "Γιαούρτι", "Dairy & Eggs", 1.99, "unit", "Greek style yogurt.", "Γιαούρτι στραγγιστό.", "500g pot.", "product_yogurt_dairy_eggs", availabilityAmount = 60),

            // Meat & Seafood
            Product(14, "Chicken Breast", "Στήθος Κοτόπουλο", "Meat & Seafood", 9.99, "kilo", "Skinless chicken breast fillets.", "Φιλέτα στήθος κοτόπουλου χωρίς πέτσα.", "Lean and high in protein.", "product_chicken_meat_seafood", availabilityAmount = 25),
            Product(15, "Pork Chops", "Χοιρινές Μπριζόλες", "Meat & Seafood", 7.99, "kilo", "Thick-cut pork chops.", "Χοιρινές μπριζόλες με κόκαλο.", "Perfect for grilling.", "product_porkchops_meat_seafood", availabilityAmount = 20),
            Product(16, "Salmon Fillet", "Φιλέτο Σολομού", "Meat & Seafood", 19.99, "kilo", "Fresh Atlantic salmon.", "Φρέσκος σολομός Ατλαντικού.", "Rich in Omega-3.", "product_salmonfilet_meat_seafood", availabilityAmount = 15),
            Product(17, "Shrimps", "Γαρίδες", "Meat & Seafood", 15.99, "kilo", "Large raw shrimps.", "Μεγάλες ωμές γαρίδες.", "Ideal for pasta or paella.", "product_shrimps_meat_seafood", availabilityAmount = 18),
            Product(18, "Turkey Slices", "Φέτες Γαλοπούλας", "Meat & Seafood", 12.49, "kilo", "Sliced smoked turkey.", "Καπνιστή γαλοπούλα σε φέτες.", "Great for sandwiches.", "product_turkeyslices_meat_seafood", availabilityAmount = 35),

            // Pantry Essentials
            Product(19, "Black Pepper", "Μαύρο Πιπέρι", "Pantry Essentials", 2.99, "unit", "Whole black peppercorns.", "Ολόκληροι κόκκοι μαύρου πιπεριού.", "50g grinder.", "product_blackpepper_pantryessentials", availabilityAmount = 80),
            Product(20, "Honey", "Μέλι", "Pantry Essentials", 5.49, "unit", "Natural flower honey.", "Φυσικό ανθόμελο.", "450g jar.", "product_honey_pantryessentials", availabilityAmount = 40),
            Product(21, "Olive Oil", "Ελαιόλαδο", "Pantry Essentials", 9.99, "litre", "Extra virgin olive oil.", "Εξαιρετικό παρθένο ελαιόλαδο.", "1 litre tin.", "product_oliveoil_pantryessentials", availabilityAmount = 50),
            Product(22, "Rice", "Ρύζι", "Pantry Essentials", 2.19, "kilo", "Long-grain white rice.", "Μακρύκοκκο λευκό ρύζι.", "1kg bag.", "product_rice_pantryessentials", availabilityAmount = 150),
            Product(23, "Salt", "Αλάτι", "Pantry Essentials", 0.99, "unit", "Fine sea salt.", "Ψιλό θαλασσινό αλάτι.", "500g box.", "product_salt_pantryessentials", availabilityAmount = 200),
            Product(24, "Spaghetti", "Σπαγγέτι", "Pantry Essentials", 1.29, "unit", "Durum wheat spaghetti.", "Σπαγγέτι από σκληρό σιτάρι.", "500g pack.", "product_spaghetti_pantryessentials", availabilityAmount = 100, ingredientsList = "Durum Wheat Semolina, Water"),
            Product(25, "White Bread", "Λευκό Ψωμί", "Pantry Essentials", 1.99, "unit", "Sliced white bread.", "Λευκό ψωμί σε φέτες.", "700g loaf.", "product_whitebread_pantryessentials", availabilityAmount = 60, ingredientsList = "Flour, Water, Yeast, Salt, Sugar"),

            // Beverages
            Product(26, "Cola", "Κόλα", "Beverages", 1.50, "litre", "Classic cola drink.", "Κλασικό αναψυκτικό κόλα.", "1.5 litre bottle.", "product_cola_beverages", availabilityAmount = 100),
            Product(27, "Ice Tea", "Παγωμένο Τσάι", "Beverages", 1.79, "litre", "Lemon-flavored ice tea.", "Παγωμένο τσάι με γεύση λεμόνι.", "1.5 litre bottle.", "product_icetea_beverages", availabilityAmount = 80),
            Product(28, "Orange Juice", "Χυμός Πορτοκάλι", "Beverages", 2.49, "litre", "100% pure orange juice.", "100% φυσικός χυμός πορτοκάλι.", "1 litre carton.", "product_orangejuice_beverages", availabilityAmount = 70),
            Product(29, "Sparkling Water", "Ανθρακούχο Νερό", "Beverages", 0.89, "litre", "Natural sparkling mineral water.", "Φυσικό μεταλλικό ανθρακούχο νερό.", "1 litre bottle.", "product_sparklingwater_beverages", availabilityAmount = 120),
            Product(30, "Water", "Νερό", "Beverages", 0.50, "litre", "Still mineral water.", "Επιτραπέζιο νερό.", "1.5 litre bottle.", "product_water_beverages", availabilityAmount = 200),

            // Household Items
            Product(31, "Dish Soap", "Σαπούνι Πιάτων", "Household Items", 2.29, "unit", "Lemon scented dish soap.", "Σαπούνι πιάτων με άρωμα λεμόνι.", "500ml bottle.", "product_dishsoap_householditems", availabilityAmount = 60),
            Product(32, "Hand Soap", "Σαπούνι Χεριών", "Household Items", 1.99, "unit", "Moisturizing hand soap.", "Ενυδατικό σαπούνι χεριών.", "250ml dispenser.", "product_handsoap_householditems", availabilityAmount = 70),
            Product(33, "Toilet Paper", "Χαρτί Τουαλέτας", "Household Items", 4.99, "unit", "Pack of 8 toilet paper rolls.", "Πακέτο 8 ρολά χαρτί τουαλέτας.", "3-ply soft paper.", "product_toiletpaper_householditems", availabilityAmount = 50),
            Product(34, "Toothbrush", "Οδοντόβουρτσα", "Household Items", 2.99, "unit", "Medium bristle toothbrush.", "Οδοντόβουρτσα με μεσαίες ίνες.", "Single pack.", "product_toothbrush_householditems", availabilityAmount = 90),
            Product(35, "Toothpaste", "Οδοντόκρεμα", "Household Items", 3.49, "unit", "Fluoride toothpaste for cavity protection.", "Οδοντόκρεμα με φθόριο για προστασία.", "100ml tube.", "product_toothpaste_householditems", availabilityAmount = 80)
        )
    }
} 