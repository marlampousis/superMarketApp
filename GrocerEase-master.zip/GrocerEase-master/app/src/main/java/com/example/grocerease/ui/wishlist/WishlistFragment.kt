package com.example.grocerease.ui.wishlist

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.grocerease.GrocerEaseApplication
import com.example.grocerease.databinding.FragmentWishlistBinding
import com.example.grocerease.ui.ViewModelFactory

class WishlistFragment : Fragment() {

    private var _binding: FragmentWishlistBinding? = null
    private val binding get() = _binding!!
    private lateinit var wishlistViewModel: WishlistViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentWishlistBinding.inflate(inflater, container, false)
        val root: View = binding.root

        val application = requireActivity().application as GrocerEaseApplication
        val viewModelFactory = ViewModelFactory(
            application.productRepository,
            application.categoryRepository,
            application.shoppingListRepository,
            application.wishlistRepository,
            application.purchaseRepository
        )
        wishlistViewModel = ViewModelProvider(this, viewModelFactory)[WishlistViewModel::class.java]

        wishlistViewModel.wishlistItems.observe(viewLifecycleOwner) {
            // Do something with wishlist items
        }

        binding.textWishlist.text = "This is wishlist Fragment"

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
} 