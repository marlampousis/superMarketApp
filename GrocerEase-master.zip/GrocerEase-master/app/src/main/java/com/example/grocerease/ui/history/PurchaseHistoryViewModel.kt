package com.example.grocerease.ui.history

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.example.grocerease.data.database.entities.Purchase
import com.example.grocerease.data.repository.PurchaseRepository

class PurchaseHistoryViewModel(private val purchaseRepository: PurchaseRepository) : ViewModel() {

    val allPurchases: LiveData<List<Purchase>> = purchaseRepository.allPurchases
} 