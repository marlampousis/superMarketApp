package com.example.grocerease.ui.shopping

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.grocerease.GrocerEaseApplication
import com.example.grocerease.databinding.FragmentShoppingListBinding
import com.example.grocerease.ui.ViewModelFactory

class ShoppingListFragment : Fragment() {

    private var _binding: FragmentShoppingListBinding? = null
    private val binding get() = _binding!!
    private lateinit var shoppingListViewModel: ShoppingListViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentShoppingListBinding.inflate(inflater, container, false)
        val root: View = binding.root

        val application = requireActivity().application as GrocerEaseApplication
        val viewModelFactory = ViewModelFactory(
            application.productRepository,
            application.categoryRepository,
            application.shoppingListRepository,
            application.wishlistRepository,
            application.purchaseRepository
        )
        shoppingListViewModel = ViewModelProvider(this, viewModelFactory)[ShoppingListViewModel::class.java]

        shoppingListViewModel.shoppingListItems.observe(viewLifecycleOwner) {
            // Do something with shopping list items
        }

        binding.textShoppingList.text = "This is shopping list Fragment"
        
        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
} 