package com.example.grocerease.data.models

data class SpendingByTime(
    val timeKey: String,
    val total: Double
) 