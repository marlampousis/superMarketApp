package com.example.grocerease.data.database.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class Product(
    @PrimaryKey val id: Int,
    val name: String,
    val nameEl: String,
    val category: String,
    val price: Double,
    val unit: String, //unit/litre/kilo
    val description: String,
    val descriptionEl: String,
    val nutritionalInfo: String,
    val imageResourceName: String, // Links to drawable resources
    val isOnSale: Boolean = false,
    val salePrice: Double? = null,
    val isAvailable: Boolean = true,
    val availabilityAmount: Int,
    val ingredientsList: String? = null //only for packaged products
) 