package com.example.grocerease

import android.app.Application
import com.example.grocerease.data.database.AppDatabase
import com.example.grocerease.data.repository.CategoryRepository
import com.example.grocerease.data.repository.ProductRepository
import com.example.grocerease.data.repository.PurchaseRepository
import com.example.grocerease.data.repository.ShoppingListRepository
import com.example.grocerease.data.repository.WishlistRepository

class GrocerEaseApplication : Application() {

    private val database by lazy { AppDatabase.getDatabase(this) }

    val productRepository by lazy { ProductRepository(database.productDao()) }
    val categoryRepository by lazy { CategoryRepository(database.categoryDao()) }
    val shoppingListRepository by lazy { ShoppingListRepository(database.shoppingListDao()) }
    val wishlistRepository by lazy { WishlistRepository(database.wishlistDao()) }
    val purchaseRepository by lazy { PurchaseRepository(database.purchaseDao()) }

} 