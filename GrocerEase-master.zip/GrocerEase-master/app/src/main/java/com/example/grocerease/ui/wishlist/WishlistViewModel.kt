package com.example.grocerease.ui.wishlist

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.grocerease.data.database.entities.WishlistItem
import com.example.grocerease.data.repository.WishlistRepository
import kotlinx.coroutines.launch

class WishlistViewModel(private val wishlistRepository: WishlistRepository) : ViewModel() {

    val wishlistItems: LiveData<List<WishlistItem>> = wishlistRepository.allItems

    fun addItem(item: WishlistItem) = viewModelScope.launch {
        wishlistRepository.addItem(item)
    }

    fun removeItem(itemId: Int) = viewModelScope.launch {
        wishlistRepository.removeItem(itemId)
    }

    fun isInWishlist(productId: Int): LiveData<Int> {
        return wishlistRepository.isInWishlist(productId)
    }
} 