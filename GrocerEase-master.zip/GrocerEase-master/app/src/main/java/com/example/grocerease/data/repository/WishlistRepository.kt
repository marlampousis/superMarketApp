package com.example.grocerease.data.repository

import androidx.lifecycle.LiveData
import com.example.grocerease.data.dao.WishlistDao
import com.example.grocerease.data.database.entities.WishlistItem

class WishlistRepository(private val wishlistDao: WishlistDao) {

    val allItems: LiveData<List<WishlistItem>> = wishlistDao.getAllItems()

    suspend fun addItem(item: WishlistItem) {
        wishlistDao.addItem(item)
    }

    suspend fun removeItem(itemId: Int) {
        wishlistDao.removeItem(itemId)
    }

    fun isInWishlist(productId: Int): LiveData<Int> {
        return wishlistDao.isInWishlist(productId)
    }

    suspend fun updateQuantity(itemId: Int, quantity: Int) {
        wishlistDao.updateQuantity(itemId, quantity)
    }
} 