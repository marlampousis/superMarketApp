package com.example.grocerease.ui.products

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.grocerease.GrocerEaseApplication
import com.example.grocerease.R
import com.example.grocerease.data.database.entities.Product
import com.example.grocerease.databinding.FragmentProductListBinding
import com.example.grocerease.ui.ViewModelFactory

class ProductListFragment : Fragment() {

    private var _binding: FragmentProductListBinding? = null
    private val binding get() = _binding!!
    private lateinit var productListViewModel: ProductListViewModel
    private lateinit var productAdapter: ProductAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentProductListBinding.inflate(inflater, container, false)
        val root: View = binding.root

        val application = requireActivity().application as GrocerEaseApplication
        val viewModelFactory = ViewModelFactory(
            application.productRepository,
            application.categoryRepository,
            application.shoppingListRepository,
            application.wishlistRepository,
            application.purchaseRepository
        )
        productListViewModel = ViewModelProvider(this, viewModelFactory)[ProductListViewModel::class.java]

        setupRecyclerView()

        productListViewModel.products.observe(viewLifecycleOwner) { products ->
            productAdapter.submitList(products)
        }

        return root
    }

    private fun setupRecyclerView() {
        productAdapter = ProductAdapter()
        binding.recyclerViewProducts.apply {
            adapter = productAdapter
            layoutManager = GridLayoutManager(context, 2)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    inner class ProductAdapter : androidx.recyclerview.widget.ListAdapter<Product, ProductAdapter.ProductViewHolder>(ProductDiffCallback()) {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_product, parent, false)
            return ProductViewHolder(view)
        }

        override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
            holder.bind(getItem(position))
        }

        inner class ProductViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            private val nameTextView: TextView = itemView.findViewById(R.id.product_name)
            private val priceTextView: TextView = itemView.findViewById(R.id.product_price)
            private val imageView: ImageView = itemView.findViewById(R.id.product_image)

            fun bind(product: Product) {
                nameTextView.text = product.name
                priceTextView.text = "$${product.price}/${product.unit}"
                val imageResId = resources.getIdentifier(product.imageResourceName, "drawable", requireContext().packageName)
                Glide.with(itemView.context)
                    .load(imageResId)
                    .placeholder(R.drawable.ic_launcher_background)
                    .error(R.drawable.ic_launcher_foreground)
                    .into(imageView)
            }
        }
    }

    class ProductDiffCallback : androidx.recyclerview.widget.DiffUtil.ItemCallback<Product>() {
        override fun areItemsTheSame(oldItem: Product, newItem: Product): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Product, newItem: Product): Boolean {
            return oldItem == newItem
        }
    }
} 