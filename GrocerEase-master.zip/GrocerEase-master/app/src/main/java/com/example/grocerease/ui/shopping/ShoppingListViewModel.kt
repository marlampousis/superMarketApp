package com.example.grocerease.ui.shopping

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.grocerease.data.database.entities.ShoppingListItem
import com.example.grocerease.data.repository.ShoppingListRepository
import kotlinx.coroutines.launch

class ShoppingListViewModel(private val shoppingListRepository: ShoppingListRepository) : ViewModel() {

    val shoppingListItems: LiveData<List<ShoppingListItem>> = shoppingListRepository.allItems

    fun addItem(item: ShoppingListItem) = viewModelScope.launch {
        shoppingListRepository.addItem(item)
    }

    fun removeItem(itemId: Int) = viewModelScope.launch {
        shoppingListRepository.removeItem(itemId)
    }

    fun updateQuantity(itemId: Int, quantity: Int) = viewModelScope.launch {
        shoppingListRepository.updateQuantity(itemId, quantity)
    }

    fun clearCompleted() = viewModelScope.launch {
        shoppingListRepository.clearCompleted()
    }
} 