package com.example.grocerease.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.grocerease.data.repository.CategoryRepository
import com.example.grocerease.data.repository.ProductRepository
import com.example.grocerease.data.repository.PurchaseRepository
import com.example.grocerease.data.repository.ShoppingListRepository
import com.example.grocerease.data.repository.WishlistRepository
import com.example.grocerease.ui.history.PurchaseHistoryViewModel
import com.example.grocerease.ui.home.HomeViewModel
import com.example.grocerease.ui.products.ProductListViewModel
import com.example.grocerease.ui.shopping.ShoppingListViewModel
import com.example.grocerease.ui.wishlist.WishlistViewModel

class ViewModelFactory(
    private val productRepository: ProductRepository,
    private val categoryRepository: CategoryRepository,
    private val shoppingListRepository: ShoppingListRepository,
    private val wishlistRepository: WishlistRepository,
    private val purchaseRepository: PurchaseRepository
) : ViewModelProvider.Factory {

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(HomeViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return HomeViewModel(productRepository, categoryRepository) as T
        }
        if (modelClass.isAssignableFrom(ProductListViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ProductListViewModel(productRepository) as T
        }
        if (modelClass.isAssignableFrom(ShoppingListViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ShoppingListViewModel(shoppingListRepository) as T
        }
        if (modelClass.isAssignableFrom(WishlistViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return WishlistViewModel(wishlistRepository) as T
        }
        if (modelClass.isAssignableFrom(PurchaseHistoryViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return PurchaseHistoryViewModel(purchaseRepository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
} 