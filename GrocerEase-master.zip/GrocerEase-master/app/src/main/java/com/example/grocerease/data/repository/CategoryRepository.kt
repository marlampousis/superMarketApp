package com.example.grocerease.data.repository

import androidx.lifecycle.LiveData
import com.example.grocerease.data.dao.CategoryDao
import com.example.grocerease.data.database.entities.Category

class CategoryRepository(private val categoryDao: CategoryDao) {

    val allCategories: LiveData<List<Category>> = categoryDao.getAllCategories()
} 