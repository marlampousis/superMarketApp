package com.example.grocerease.data.repository

import androidx.lifecycle.LiveData
import com.example.grocerease.data.dao.ProductDao
import com.example.grocerease.data.database.entities.Product

class ProductRepository(private val productDao: ProductDao) {

    val allProducts: LiveData<List<Product>> = productDao.getAllProducts()

    fun getProductsByCategory(categoryName: String): LiveData<List<Product>> {
        return productDao.getProductsByCategory(categoryName)
    }

    fun searchProducts(query: String): LiveData<List<Product>> {
        return productDao.searchProducts("%$query%")
    }

    fun getProductById(productId: Int): LiveData<Product> {
        return productDao.getProductById(productId)
    }
} 