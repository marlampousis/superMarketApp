package com.example.grocerease.data.dao

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.grocerease.data.database.entities.Purchase
import com.example.grocerease.data.database.entities.PurchaseItem
import com.example.grocerease.data.models.SpendingByTime

@Dao
interface PurchaseDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPurchase(purchase: Purchase): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPurchaseItems(purchaseItems: List<PurchaseItem>)

    @Update
    suspend fun updatePurchase(purchase: Purchase)

    @Delete
    suspend fun deletePurchase(purchase: Purchase)

    @Query("SELECT * FROM purchases WHERE id = :purchaseId")
    fun getPurchaseById(purchaseId: Int): LiveData<Purchase>

    @Query("SELECT * FROM purchases ORDER BY purchaseDate DESC")
    fun getAllPurchases(): LiveData<List<Purchase>>

    @Query("SELECT * FROM purchases ORDER BY purchaseDate DESC LIMIT :limit")
    fun getRecentPurchases(limit: Int): LiveData<List<Purchase>>

    @Query("SELECT * FROM purchases WHERE purchaseDate BETWEEN :startOfWeek AND :endOfWeek")
    fun getPurchasesByWeek(startOfWeek: Long, endOfWeek: Long): LiveData<List<Purchase>>

    @Query("SELECT * FROM purchases WHERE purchaseDate BETWEEN :startOfMonth AND :endOfMonth")
    fun getPurchasesByMonth(startOfMonth: Long, endOfMonth: Long): LiveData<List<Purchase>>

    @Query("SELECT SUM(totalAmountPaid) FROM purchases WHERE purchaseDate BETWEEN :startOfWeek AND :endOfWeek")
    fun getWeeklyTotal(startOfWeek: Long, endOfWeek: Long): LiveData<Double>

    @Query("SELECT SUM(totalAmountPaid) FROM purchases WHERE purchaseDate BETWEEN :startOfMonth AND :endOfMonth")
    fun getMonthlyTotal(startOfMonth: Long, endOfMonth: Long): LiveData<Double>
    
    // These might be better calculated in the ViewModel based on weekly/monthly totals
    // For now, providing the raw data queries.
    @Query("SELECT strftime('%Y-%W', purchaseDate / 1000, 'unixepoch') as timeKey, SUM(totalAmountPaid) as total FROM purchases GROUP BY timeKey")
    fun getWeeklySpendingComparison(): LiveData<List<SpendingByTime>>

    @Query("SELECT strftime('%Y-%m', purchaseDate / 1000, 'unixepoch') as timeKey, SUM(totalAmountPaid) as total FROM purchases GROUP BY timeKey")
    fun getMonthlySpendingComparison(): LiveData<List<SpendingByTime>>
} 