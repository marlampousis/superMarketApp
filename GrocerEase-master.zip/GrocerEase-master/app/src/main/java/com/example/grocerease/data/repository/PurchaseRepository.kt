package com.example.grocerease.data.repository

import androidx.lifecycle.LiveData
import com.example.grocerease.data.dao.PurchaseDao
import com.example.grocerease.data.database.entities.Purchase
import com.example.grocerease.data.database.entities.PurchaseItem

class PurchaseRepository(private val purchaseDao: PurchaseDao) {

    val allPurchases: LiveData<List<Purchase>> = purchaseDao.getAllPurchases()

    suspend fun insertPurchase(purchase: Purchase, items: List<PurchaseItem>) {
        val purchaseId = purchaseDao.insertPurchase(purchase)
        val purchaseItemsWithId = items.map { it.copy(purchaseId = purchaseId.toInt()) }
        purchaseDao.insertPurchaseItems(purchaseItemsWithId)
    }

    suspend fun updatePurchase(purchase: Purchase) {
        purchaseDao.updatePurchase(purchase)
    }

    suspend fun deletePurchase(purchase: Purchase) {
        purchaseDao.deletePurchase(purchase)
    }

    fun getPurchaseById(purchaseId: Int): LiveData<Purchase> {
        return purchaseDao.getPurchaseById(purchaseId)
    }

    fun getRecentPurchases(limit: Int): LiveData<List<Purchase>> {
        return purchaseDao.getRecentPurchases(limit)
    }

    fun getPurchasesByWeek(startOfWeek: Long, endOfWeek: Long): LiveData<List<Purchase>> {
        return purchaseDao.getPurchasesByWeek(startOfWeek, endOfWeek)
    }

    fun getPurchasesByMonth(startOfMonth: Long, endOfMonth: Long): LiveData<List<Purchase>> {
        return purchaseDao.getPurchasesByMonth(startOfMonth, endOfMonth)
    }
} 