package com.example.grocerease.ui.history

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.grocerease.GrocerEaseApplication
import com.example.grocerease.databinding.FragmentPurchaseHistoryBinding
import com.example.grocerease.ui.ViewModelFactory

class PurchaseHistoryFragment : Fragment() {

    private var _binding: FragmentPurchaseHistoryBinding? = null
    private val binding get() = _binding!!
    private lateinit var purchaseHistoryViewModel: PurchaseHistoryViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPurchaseHistoryBinding.inflate(inflater, container, false)
        val root: View = binding.root

        val application = requireActivity().application as GrocerEaseApplication
        val viewModelFactory = ViewModelFactory(
            application.productRepository,
            application.categoryRepository,
            application.shoppingListRepository,
            application.wishlistRepository,
            application.purchaseRepository
        )
        purchaseHistoryViewModel =
            ViewModelProvider(this, viewModelFactory)[PurchaseHistoryViewModel::class.java]

        purchaseHistoryViewModel.allPurchases.observe(viewLifecycleOwner) {
            // Do something with purchase history
        }

        binding.textHistory.text = "This is purchase history Fragment"

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
} 