package com.example.grocerease.ui.home

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.example.grocerease.data.database.entities.Category
import com.example.grocerease.data.database.entities.Product
import com.example.grocerease.data.repository.CategoryRepository
import com.example.grocerease.data.repository.ProductRepository

class HomeViewModel(
    private val productRepository: ProductRepository,
    private val categoryRepository: CategoryRepository
) : ViewModel() {

    val categories: LiveData<List<Category>> = categoryRepository.allCategories
    val onSaleProducts: LiveData<List<Product>> = productRepository.allProducts // This should be filtered for onSaleProducts
    val recentPurchases: LiveData<List<Product>> = productRepository.allProducts // This should be from purchase repository
} 