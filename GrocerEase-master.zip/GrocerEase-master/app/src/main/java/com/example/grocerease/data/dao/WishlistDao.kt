package com.example.grocerease.data.dao

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.grocerease.data.database.entities.WishlistItem

@Dao
interface WishlistDao {
    @Query("SELECT * FROM wishlist")
    fun getAllItems(): LiveData<List<WishlistItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addItem(item: WishlistItem)

    @Query("DELETE FROM wishlist WHERE id = :itemId")
    suspend fun removeItem(itemId: Int)

    @Query("SELECT COUNT(*) FROM wishlist WHERE productId = :productId")
    fun isInWishlist(productId: Int): LiveData<Int>

    @Query("UPDATE wishlist SET quantity = :quantity WHERE id = :itemId")
    suspend fun updateQuantity(itemId: Int, quantity: Int)
} 