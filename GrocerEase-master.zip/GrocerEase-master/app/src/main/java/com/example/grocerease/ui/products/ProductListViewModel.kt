package com.example.grocerease.ui.products

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.switchMap
import com.example.grocerease.data.database.entities.Product
import com.example.grocerease.data.repository.ProductRepository

class ProductListViewModel(private val productRepository: ProductRepository) : ViewModel() {

    private val _filter = androidx.lifecycle.MutableLiveData<String?>(null)

    val products: LiveData<List<Product>> = _filter.switchMap { filter ->
        if (filter.isNullOrEmpty()) {
            productRepository.allProducts
        } else {
            productRepository.getProductsByCategory(filter)
        }
    }

    fun setFilter(categoryName: String?) {
        _filter.value = categoryName
    }
} 