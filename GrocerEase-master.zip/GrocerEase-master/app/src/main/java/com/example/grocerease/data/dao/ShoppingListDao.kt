package com.example.grocerease.data.dao

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.grocerease.data.database.entities.ShoppingListItem

@Dao
interface ShoppingListDao {
    @Query("SELECT * FROM shopping_list WHERE isCompleted = 0")
    fun getAllItems(): LiveData<List<ShoppingListItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addItem(item: ShoppingListItem)

    @Query("DELETE FROM shopping_list WHERE id = :itemId")
    suspend fun removeItem(itemId: Int)

    @Query("UPDATE shopping_list SET quantity = :quantity WHERE id = :itemId")
    suspend fun updateQuantity(itemId: Int, quantity: Int)

    @Query("UPDATE shopping_list SET isCompleted = 1 WHERE isCompleted = 0")
    suspend fun clearCompleted()
} 